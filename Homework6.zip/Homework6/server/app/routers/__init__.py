"""Router package for API endpoints."""
