from fastapi import APIRouter, HTTPException
from ..models import MemoryIn, MemoryOut
from ..memory_repo import add_memory, list_memories

router = APIRouter(prefix="/memories", tags=["memories"])

@router.post("", response_model=MemoryOut, status_code=201)
async def create_memory(mem: MemoryIn):
    try:
        return await add_memory(mem)
    except Exception as e:
        # TEMP: print full error to the server console and return details
        print("ERROR creating memory:", repr(e))
        raise HTTPException(status_code=500, detail=f"{type(e).__name__}: {e}")

@router.get("/{user_id}", response_model=list[MemoryOut])
async def get_memories(user_id: str, limit: int = 50, tags: str | None = None):
    tag_list = tags.split(",") if tags else None
    return await list_memories(user_id, tag_list, limit)
