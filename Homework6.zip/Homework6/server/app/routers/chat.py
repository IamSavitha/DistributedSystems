# app/routers/chat.py
from fastapi import APIRouter, HTTPException
from ..models import ChatRequest, ChatResponse, MemoryIn
from ..memory_repo import topk_recent, add_memory
from ..ollama import generate_sync

router = APIRouter(prefix="/chat", tags=["chat"])

SYS_PROMPT = """You are a helpful assistant with access to the user's recent memories.
Use them only if relevant. Be concise and accurate."""

def build_prompt(message: str, memories: list[dict]) -> str:
    """Combine short-term memories and current message into one prompt."""
    mem_block = "\n".join(
        [f"- [{m['created_at'].isoformat()}] {m['role']}: {m['text']}" for m in memories]
    )
    return f"""Relevant memories (most recent first):
{mem_block if mem_block else '(none)'}
---
User: {message}
Assistant:"""

@router.post("", response_model=ChatResponse)
async def chat(req: ChatRequest):
    """Main chat endpoint: builds prompt, calls Ollama, stores reply."""
    try:
        # 1. Get recent memories for short-term context
        memories = await topk_recent(req.user_id, req.k, req.tags)

        # 2️ Build the prompt and call the LLM
        prompt = build_prompt(req.message, memories)
        print("\n--- Ollama Prompt ---\n", prompt[:500], "\n----------------------")
        answer = generate_sync(prompt, system=SYS_PROMPT)

        # 3️ Save user message and AI reply to MongoDB
        await add_memory(MemoryIn(
            user_id=req.user_id, role="user", text=req.message, tags=req.tags or []
        ))
        await add_memory(MemoryIn(
            user_id=req.user_id, role="assistant", text=answer, tags=["ai-reply"]
        ))

        print("\n Ollama returned answer:", answer[:200])
        return ChatResponse(answer=answer, used_memories=memories)

    except Exception as e:
        # Log the detailed reason
        print(" CHAT ERROR:", repr(e))
        raise HTTPException(status_code=500, detail=f"Chat failed: {e}")
