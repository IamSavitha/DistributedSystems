"""Marks the 'app' directory as a Python package."""
